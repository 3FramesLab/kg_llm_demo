# OpenShift Deployment Changes

This folder contains all the required changes to deploy the dq-poc application to OpenShift.

## Quick Start

1. Copy your code to the root directory (where `proj-api` and `web-app` folders are)
2. Run the deployment script:

### Option 1: Deploy Both (Backend + Frontend)
```bash
cd CHANGES
chmod +x deploy.sh
./deploy.sh
```

### Option 2: Deploy Backend Only
```bash
cd CHANGES
chmod +x deploy-backend.sh
./deploy-backend.sh
```

### Option 3: Deploy Frontend Only
```bash
cd CHANGES
chmod +x deploy-frontend.sh
./deploy-frontend.sh
```

## What This Does

The deployment scripts will:
1. Apply all backend code changes (Graphiti, ODBC Driver 18, etc.) - backend script
2. Apply all frontend code changes (nginx, API routing, etc.) - frontend script
3. Build and deploy applications to OpenShift
4. Configure environment variables (backend only)
5. Verify deployments are running

## Directory Structure

```
CHANGES/
├── README.md              # This file
├── QUICKSTART.md          # Quick start guide
├── deploy.sh              # Main deployment script (backend + frontend)
├── deploy-backend.sh      # Backend only deployment script
├── deploy-frontend.sh     # Frontend only deployment script
├── backend/               # Backend code changes
│   ├── Dockerfile         # Backend Dockerfile with ODBC Driver 18
│   └── graphiti_backend.py  # Graphiti with FalkorDB Redis URI
├── frontend/              # Frontend code changes
│   ├── Dockerfile         # Frontend Dockerfile with OpenShift compatibility
│   ├── nginx-main.conf    # Main nginx config
│   ├── nginx.conf         # Site nginx config
│   └── api.js             # API service with relative paths
└── openshift/             # OpenShift configuration
    └── env-vars.txt       # Environment variables to set
```

## Manual Steps (if needed)

If you prefer to apply changes manually:

### 1. Backend Changes

```bash
# Copy backend files
cp CHANGES/backend/graphiti_backend.py proj-api/kg_builder/services/

# Build backend
oc start-build kg-builder-backend --from-dir=proj-api --follow

# Deploy backend
oc rollout restart deployment/kg-builder-backend
```

### 2. Frontend Changes

```bash
# Copy frontend files
cp CHANGES/frontend/Dockerfile web-app/
cp CHANGES/frontend/nginx-main.conf web-app/
cp CHANGES/frontend/nginx.conf web-app/
cp CHANGES/frontend/api.js web-app/src/services/

# Build frontend
oc start-build kg-builder-web --from-dir=web-app --follow

# Deploy frontend
oc rollout restart deployment/kg-builder-web
```

### 3. Environment Variables

```bash
# Apply environment variables
oc set env deployment/kg-builder-backend \
  FALKORDB_HOST=redis-cluster-service.cognito-ai-redis-dev.svc.cluster.local \
  FALKORDB_PORT=6379 \
  FALKORDB_PASSWORD=devredis123! \
  OPENAI_MODEL=gpt-4o \
  OPENAI_TEMPERATURE=0 \
  KPI_DB_TYPE=sqlserver \
  KPI_DB_HOST=mssql.cognito-ai-dq-dev.svc.cluster.local \
  KPI_DB_PORT=1433 \
  KPI_DB_DATABASE=KPI_Analytics \
  KPI_DB_USERNAME=sa \
  KPI_DB_PASSWORD=YourStrong!Passw0rd
```

## Prerequisites

- OpenShift CLI (`oc`) installed and logged in
- Access to the `cognito-ai-dq-dev` namespace
- BuildConfig and DeploymentConfig already created in OpenShift

## Files Modified

### Backend (proj-api)
- `kg_builder/services/graphiti_backend.py` - Added FalkorDB Redis URI configuration
- `kg_builder/services/landing_kpi_service_mssql.py` - Already has ODBC Driver 18
- `Dockerfile` - Already has ODBC Driver 18 installation

### Frontend (web-app)
- `Dockerfile` - OpenShift compatibility (port 8080, permissions, --legacy-peer-deps)
- `nginx-main.conf` - PID file workaround
- `nginx.conf` - Port 8080 and backend service routing
- `src/services/api.js` - Relative paths for production

## Troubleshooting

### Check Build Status
```bash
oc get builds
oc logs -f bc/kg-builder-backend
oc logs -f bc/kg-builder-web
```

### Check Pod Status
```bash
oc get pods
oc logs -f <pod-name>
```

### Check Deployment Status
```bash
oc get deployment
oc rollout status deployment/kg-builder-backend
oc rollout status deployment/kg-builder-web
```

### Common Issues

1. **Build fails** - Check the build logs: `oc logs -f bc/kg-builder-backend`
2. **Pod not starting** - Check pod logs: `oc logs <pod-name>`
3. **Permission denied** - Check Dockerfile has correct permissions for group 0
4. **API calls failing** - Check nginx.conf has correct backend service name

## Support

For issues, check the main project documentation or deployment summary.
