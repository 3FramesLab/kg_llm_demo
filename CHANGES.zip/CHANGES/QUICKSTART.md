# Quick Start Guide

Deploy the dq-poc application to OpenShift in 3 simple steps.

## Prerequisites

- OpenShift CLI (`oc`) installed
- Logged in to OpenShift cluster
- Access to `cognito-ai-dq-dev` namespace
- BuildConfig and DeploymentConfig already created

## Steps

### 1. Copy your code to root directory

Make sure your code is in the following structure:
```
dq-poc/
├── proj-api/         # Your backend code
├── web-app/          # Your frontend code
└── CHANGES/          # This deployment folder
```

### 2. Run the deployment script

```bash
cd CHANGES
chmod +x deploy.sh
./deploy.sh
```

### 3. Verify deployment

The script will automatically:
- Copy all required files
- Set environment variables
- Build backend and frontend images
- Deploy both applications
- Show deployment status

## What Gets Deployed

### Backend Changes
- **Graphiti Backend**: FalkorDB Redis URI configuration
- **ODBC Driver 18**: SQL Server connectivity
- **Environment Variables**: FalkorDB, OpenAI, KPI Database configs

### Frontend Changes
- **OpenShift-compatible Dockerfile**: Port 8080, proper permissions
- **Nginx Configuration**: API proxy to backend service
- **API Service**: Relative paths for production routing

## Access Your Application

After deployment completes, get the application URL:
```bash
oc get routes | grep kg-builder-web
```

## Troubleshooting

### Check Build Status
```bash
oc get builds
oc logs -f bc/kg-builder-backend
```

### Check Pod Logs
```bash
oc get pods
oc logs -f <pod-name>
```

### Check Deployment Status
```bash
oc get deployment
oc rollout status deployment/kg-builder-backend
oc rollout status deployment/kg-builder-web
```

## Manual Deployment

If you prefer manual steps, see [README.md](README.md) for detailed instructions.

## Support

For detailed documentation, troubleshooting, and manual deployment steps, see [README.md](README.md).
