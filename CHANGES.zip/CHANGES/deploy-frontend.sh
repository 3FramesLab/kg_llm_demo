#!/bin/bash

# OpenShift Frontend Deployment Script for dq-poc Application
# This script deploys only the frontend to OpenShift

set -e  # Exit on error

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Get script directory and change to it
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Configuration
NAMESPACE="cognito-ai-dq-dev"
FRONTEND_BUILD="kg-builder-web"
FRONTEND_DEPLOYMENT="kg-builder-web"
FRONTEND_DIR="../web-app"

echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}  Frontend Deployment Script${NC}"
echo -e "${BLUE}=====================================${NC}"
echo ""

# Check if oc is installed
if ! command -v oc &> /dev/null; then
    echo -e "${RED}ERROR: OpenShift CLI (oc) is not installed${NC}"
    echo "Please install oc from: https://docs.openshift.com/container-platform/latest/cli_reference/openshift_cli/getting-started-cli.html"
    exit 1
fi

# Check if logged in to OpenShift
echo -e "${BLUE}Checking OpenShift login status...${NC}"
if ! oc whoami &> /dev/null; then
    echo -e "${RED}ERROR: Not logged in to OpenShift${NC}"
    echo "Please run: oc login <cluster-url>"
    exit 1
fi

echo -e "${GREEN}✓ Logged in as: $(oc whoami)${NC}"

# Switch to correct namespace
echo -e "${BLUE}Switching to namespace: $NAMESPACE${NC}"
oc project $NAMESPACE || {
    echo -e "${RED}ERROR: Cannot switch to namespace $NAMESPACE${NC}"
    exit 1
}
echo -e "${GREEN}✓ Using namespace: $NAMESPACE${NC}"
echo ""

# Step 1: Apply frontend code changes
echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}Step 1: Applying frontend code changes${NC}"
echo -e "${BLUE}=====================================${NC}"

echo -e "${YELLOW}Copying frontend files...${NC}"
cp frontend/Dockerfile $FRONTEND_DIR/
cp frontend/nginx-main.conf $FRONTEND_DIR/
cp frontend/nginx.conf $FRONTEND_DIR/
cp frontend/api.js $FRONTEND_DIR/src/services/
echo -e "${GREEN}✓ Frontend files copied${NC}"
echo ""

# Step 2: Build frontend
echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}Step 2: Building frontend image${NC}"
echo -e "${BLUE}=====================================${NC}"

echo -e "${YELLOW}Starting frontend build...${NC}"
oc start-build $FRONTEND_BUILD --from-dir=$FRONTEND_DIR --follow

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Frontend build completed successfully${NC}"
else
    echo -e "${RED}ERROR: Frontend build failed${NC}"
    exit 1
fi
echo ""

# Step 3: Deploy frontend
echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}Step 3: Deploying frontend${NC}"
echo -e "${BLUE}=====================================${NC}"

echo -e "${YELLOW}Restarting frontend deployment...${NC}"
oc rollout restart deployment/$FRONTEND_DEPLOYMENT

echo -e "${YELLOW}Waiting for frontend deployment to complete...${NC}"
oc rollout status deployment/$FRONTEND_DEPLOYMENT --timeout=5m

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Frontend deployment completed${NC}"
else
    echo -e "${RED}ERROR: Frontend deployment failed${NC}"
    exit 1
fi
echo ""

# Step 4: Verify deployment
echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}Step 4: Verifying frontend deployment${NC}"
echo -e "${BLUE}=====================================${NC}"

echo -e "${YELLOW}Checking deployment status...${NC}"
oc get deployment $FRONTEND_DEPLOYMENT
echo ""

echo -e "${YELLOW}Checking pod status...${NC}"
oc get pods -l app=$FRONTEND_DEPLOYMENT
echo ""

echo -e "${YELLOW}Application route:${NC}"
ROUTE=$(oc get route kg-builder-web -o jsonpath='{.spec.host}' 2>/dev/null)
if [ -n "$ROUTE" ]; then
    echo -e "${GREEN}✓ Frontend URL: https://$ROUTE${NC}"
else
    echo -e "${YELLOW}Run: oc get routes | grep kg-builder-web${NC}"
fi
echo ""

echo -e "${YELLOW}Recent frontend logs:${NC}"
oc logs -l app=$FRONTEND_DEPLOYMENT --tail=20
echo ""

# Final status
echo -e "${GREEN}=====================================${NC}"
echo -e "${GREEN}  Frontend Deployment Completed!${NC}"
echo -e "${GREEN}=====================================${NC}"
echo ""
echo -e "${BLUE}Next steps:${NC}"
echo "1. Check frontend logs: oc logs -f deployment/$FRONTEND_DEPLOYMENT"
echo "2. Access the application at: https://$ROUTE"
echo ""
echo -e "${GREEN}Deployment summary:${NC}"
echo "- Frontend: Deployed with OpenShift-compatible nginx configuration"
echo "- Port: 8080 (OpenShift compatible)"
echo "- API Proxy: Routes /api/* requests to backend service"
echo "- Production: Using relative paths for API calls"
echo ""