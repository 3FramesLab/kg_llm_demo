#!/bin/bash

# OpenShift Deployment Script for dq-poc Application
# This script deploys both backend and frontend to OpenShift

set -e  # Exit on error

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Get script directory and change to it
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Configuration
NAMESPACE="cognito-ai-dq-dev"
BACKEND_BUILD="kg-builder-backend"
FRONTEND_BUILD="kg-builder-web"
BACKEND_DEPLOYMENT="kg-builder-backend"
FRONTEND_DEPLOYMENT="kg-builder-web"
BACKEND_DIR="../proj-api"
FRONTEND_DIR="../web-app"

echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}  OpenShift Deployment Script${NC}"
echo -e "${BLUE}=====================================${NC}"
echo ""

# Check if oc is installed
if ! command -v oc &> /dev/null; then
    echo -e "${RED}ERROR: OpenShift CLI (oc) is not installed${NC}"
    echo "Please install oc from: https://docs.openshift.com/container-platform/latest/cli_reference/openshift_cli/getting-started-cli.html"
    exit 1
fi

# Check if logged in to OpenShift
echo -e "${BLUE}Checking OpenShift login status...${NC}"
if ! oc whoami &> /dev/null; then
    echo -e "${RED}ERROR: Not logged in to OpenShift${NC}"
    echo "Please run: oc login <cluster-url>"
    exit 1
fi

echo -e "${GREEN}✓ Logged in as: $(oc whoami)${NC}"

# Switch to correct namespace
echo -e "${BLUE}Switching to namespace: $NAMESPACE${NC}"
oc project $NAMESPACE || {
    echo -e "${RED}ERROR: Cannot switch to namespace $NAMESPACE${NC}"
    exit 1
}
echo -e "${GREEN}✓ Using namespace: $NAMESPACE${NC}"
echo ""

# Step 1: Apply code changes
echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}Step 1: Applying code changes${NC}"
echo -e "${BLUE}=====================================${NC}"

# Backend changes
echo -e "${YELLOW}Copying backend files...${NC}"
cp backend/graphiti_backend.py $BACKEND_DIR/kg_builder/services/
cp backend/Dockerfile $BACKEND_DIR/
echo -e "${GREEN}✓ Backend files copied${NC}"

# Frontend changes
echo -e "${YELLOW}Copying frontend files...${NC}"
cp frontend/Dockerfile $FRONTEND_DIR/
cp frontend/nginx-main.conf $FRONTEND_DIR/
cp frontend/nginx.conf $FRONTEND_DIR/
cp frontend/api.js $FRONTEND_DIR/src/services/
echo -e "${GREEN}✓ Frontend files copied${NC}"
echo ""

# Step 2: Set environment variables
echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}Step 2: Setting environment variables${NC}"
echo -e "${BLUE}=====================================${NC}"

echo -e "${YELLOW}Applying environment variables to backend deployment...${NC}"
oc set env deployment/$BACKEND_DEPLOYMENT \
  FALKORDB_HOST=redis-cluster-service.cognito-ai-redis-dev.svc.cluster.local \
  FALKORDB_PORT=6379 \
  FALKORDB_PASSWORD=devredis123! \
  OPENAI_MODEL=gpt-4o \
  OPENAI_TEMPERATURE=0 \
  KPI_DB_TYPE=sqlserver \
  KPI_DB_HOST=mssql.cognito-ai-dq-dev.svc.cluster.local \
  KPI_DB_PORT=1433 \
  KPI_DB_DATABASE=KPI_Analytics \
  KPI_DB_USERNAME=sa \
  KPI_DB_PASSWORD=YourStrong!Passw0rd

echo -e "${GREEN}✓ Environment variables applied${NC}"
echo ""

# Step 3: Build backend
echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}Step 3: Building backend image${NC}"
echo -e "${BLUE}=====================================${NC}"

echo -e "${YELLOW}Starting backend build...${NC}"
oc start-build $BACKEND_BUILD --from-dir=$BACKEND_DIR --follow

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Backend build completed successfully${NC}"
else
    echo -e "${RED}ERROR: Backend build failed${NC}"
    exit 1
fi
echo ""

# Step 4: Build frontend
echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}Step 4: Building frontend image${NC}"
echo -e "${BLUE}=====================================${NC}"

echo -e "${YELLOW}Starting frontend build...${NC}"
oc start-build $FRONTEND_BUILD --from-dir=$FRONTEND_DIR --follow

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Frontend build completed successfully${NC}"
else
    echo -e "${RED}ERROR: Frontend build failed${NC}"
    exit 1
fi
echo ""

# Step 5: Deploy backend
echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}Step 5: Deploying backend${NC}"
echo -e "${BLUE}=====================================${NC}"

echo -e "${YELLOW}Restarting backend deployment...${NC}"
oc rollout restart deployment/$BACKEND_DEPLOYMENT

echo -e "${YELLOW}Waiting for backend deployment to complete...${NC}"
oc rollout status deployment/$BACKEND_DEPLOYMENT --timeout=5m

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Backend deployment completed${NC}"
else
    echo -e "${RED}ERROR: Backend deployment failed${NC}"
    exit 1
fi
echo ""

# Step 6: Deploy frontend
echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}Step 6: Deploying frontend${NC}"
echo -e "${BLUE}=====================================${NC}"

echo -e "${YELLOW}Restarting frontend deployment...${NC}"
oc rollout restart deployment/$FRONTEND_DEPLOYMENT

echo -e "${YELLOW}Waiting for frontend deployment to complete...${NC}"
oc rollout status deployment/$FRONTEND_DEPLOYMENT --timeout=5m

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Frontend deployment completed${NC}"
else
    echo -e "${RED}ERROR: Frontend deployment failed${NC}"
    exit 1
fi
echo ""

# Step 7: Verify deployments
echo -e "${BLUE}=====================================${NC}"
echo -e "${BLUE}Step 7: Verifying deployments${NC}"
echo -e "${BLUE}=====================================${NC}"

echo -e "${YELLOW}Checking deployment status...${NC}"
oc get deployment
echo ""

echo -e "${YELLOW}Checking pod status...${NC}"
oc get pods
echo ""

# Get routes
echo -e "${YELLOW}Application routes:${NC}"
oc get routes | grep -E "kg-builder"
echo ""

# Final status
echo -e "${GREEN}=====================================${NC}"
echo -e "${GREEN}  Deployment Completed Successfully!${NC}"
echo -e "${GREEN}=====================================${NC}"
echo ""
echo -e "${BLUE}Next steps:${NC}"
echo "1. Check backend logs: oc logs -f deployment/$BACKEND_DEPLOYMENT"
echo "2. Check frontend logs: oc logs -f deployment/$FRONTEND_DEPLOYMENT"
echo "3. Access the application using the route shown above"
echo ""
echo -e "${GREEN}Deployment summary:${NC}"
echo "- Backend: Deployed with Graphiti FalkorDB support and ODBC Driver 18"
echo "- Frontend: Deployed with OpenShift-compatible nginx configuration"
echo "- Environment: All required environment variables configured"
echo ""
