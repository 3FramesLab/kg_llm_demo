# =============================================================================
# KPI Execution Endpoint - ANNOTATED EXTRACT from kg_builder/routes.py
# =============================================================================
#
# FILE: kg_builder/routes.py
# LINES: 37 (import) and 3529-3581 (endpoint)
#
# CHANGES MADE (November 10, 2025):
# 1. Added import for get_landing_kpi_executor at top of file (line 37)
# 2. Completely rewrote execute_kpi_mssql endpoint (lines 3529-3581)
#
# WHY: Original implementation called service.execute_kpi() which had a broken
#      implementation that tried to call executor.execute_query() method that
#      doesn't exist on NLQueryExecutor.
#
# ERROR BEFORE FIX:
# {
#   "success": true,
#   "execution_id": 164,
#   "data": {
#     "execution_status": "error",
#     "error_message": "'NLQueryExecutor' object has no attribute 'execute_query'"
#   }
# }
#
# SOLUTION: Changed to proper executor pattern using get_landing_kpi_executor()
# =============================================================================

# -----------------------------------------------------------------------------
# CHANGE 1: Added Import (Line 37 of routes.py)
# -----------------------------------------------------------------------------
# WHY: Need to import get_landing_kpi_executor to use proper executor pattern
# BEFORE: Import was only inside a function scope
# AFTER: Added to top-level imports
# -----------------------------------------------------------------------------

from kg_builder.services.landing_kpi_executor import get_landing_kpi_executor


# -----------------------------------------------------------------------------
# CHANGE 2: Rewrote Execute Endpoint (Lines 3529-3581 of routes.py)
# -----------------------------------------------------------------------------
# WHY: Original implementation was broken
# OLD APPROACH: service.execute_kpi() -> executor.execute_query() ❌ (method doesn't exist)
# NEW APPROACH: executor.execute_kpi_async() ✅ (correct method)
# -----------------------------------------------------------------------------

@router.post("/landing-kpi-mssql/kpis/{kpi_id}/execute", tags=["KPI Analytics"], response_model=dict)
async def execute_kpi_mssql(kpi_id: int, request: KPIExecutionRequest):
    """Execute a KPI and return results with enhanced SQL."""
    try:
        # STEP 1: Get KPI Analytics Service
        # WHY: Service handles KPI metadata and execution records
        # PROVIDES: create_execution_record(), get_kpi(), get_execution_result()
        service = get_kpi_analytics_service()

        # STEP 2: Create Execution Record
        # WHY: Track execution in database before starting
        # RETURNS: {"id": 169, "status": "pending", ...}
        execution_record = service.create_execution_record(kpi_id, request.dict())
        execution_id = execution_record.get('id')

        # STEP 3: Get KPI Definition
        # WHY: Validate KPI exists and get metadata (name, query, etc.)
        # RETURNS: {"id": 10, "name": "Total Sales", "natural_language_query": "...", ...}
        kpi = service.get_kpi(kpi_id)
        if not kpi:
            raise HTTPException(status_code=404, detail=f"KPI ID {kpi_id} not found")

        # =====================================================================
        # STEP 4: Execute KPI Using Executor
        # =====================================================================
        # CHANGED: This is the critical fix
        # OLD CODE (BROKEN):
        #   result = service.execute_kpi(kpi_id, request.dict())
        #   # service.execute_kpi() internally called:
        #   #   executor = NLQueryExecutor(...)
        #   #   executor.execute_query(...)  ❌ Method doesn't exist!
        #
        # NEW CODE (WORKING):
        #   executor = get_landing_kpi_executor()
        #   executor.execute_kpi_async(...)  ✅ Correct method!
        # =====================================================================

        # Get the proper executor instance
        # WHY: get_landing_kpi_executor() returns LandingKPIExecutor which has
        #      execute_kpi_async() method that properly handles KPI execution
        executor = get_landing_kpi_executor()

        # Execute KPI asynchronously
        # WHY: execute_kpi_async() is the correct method that:
        #      1. Parses natural language query
        #      2. Generates SQL
        #      3. Executes against database
        #      4. Updates execution record with results
        # NOTE: This runs in background, endpoint returns immediately
        executor.execute_kpi_async(
            kpi_id=kpi_id,
            execution_id=execution_id,
            execution_params=request.dict()
        )

        # STEP 5: Get Updated Execution Results
        # WHY: After executor runs, fetch the updated execution record with results
        # RETURNS: Complete execution record with SQL, results, status, errors, etc.
        final_result = service.get_execution_result(execution_id)

        # STEP 6: Format Response
        # WHY: Frontend expects specific JSON structure
        # INCLUDES: All execution metadata, generated SQL, results, error messages
        return {
            "success": True,
            "execution_id": execution_id,
            "data": {
                # Basic execution info
                "execution_id": final_result.get('execution_id', execution_id),
                "kpi_id": final_result.get('kpi_id', kpi_id),
                "kpi_name": final_result.get('kpi_name', kpi.get('name')),
                "execution_status": final_result.get('execution_status', 'pending'),

                # Results
                "number_of_records": final_result.get('record_count', 0),
                "execution_time_ms": final_result.get('execution_time_ms', 0),

                # SQL details
                "generated_sql": final_result.get('generated_sql'),
                "enhanced_sql": final_result.get('enhanced_sql'),
                "enhancement_applied": final_result.get('enhancement_applied', False),

                # Enhancement flags
                "material_master_added": final_result.get('material_master_added', False),
                "ops_planner_added": final_result.get('ops_planner_added', False),

                # Metadata
                "confidence_score": final_result.get('confidence_score'),
                "error_message": final_result.get('error_message'),
                "data": final_result.get('data', [])
            },
            "storage_type": "mssql"
        }

    except ValueError as e:
        # Handle validation errors (invalid KPI ID, etc.)
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        # Handle unexpected errors
        logger.error(f"Error executing KPI {kpi_id} in MS SQL Server: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# =============================================================================
# SUMMARY OF CHANGES:
# =============================================================================
#
# PROBLEM:
# Original endpoint called service.execute_kpi() which internally tried to call
# executor.execute_query() method that doesn't exist on NLQueryExecutor class.
#
# SOLUTION:
# Changed to use proper executor pattern:
# 1. Added import: get_landing_kpi_executor
# 2. Get executor instance: executor = get_landing_kpi_executor()
# 3. Call correct method: executor.execute_kpi_async(kpi_id, execution_id, params)
#
# FLOW:
# 1. Create execution record (status="pending")
# 2. Get KPI definition
# 3. Execute KPI via executor.execute_kpi_async() [CHANGED - was service.execute_kpi()]
# 4. Get updated execution results
# 5. Return formatted response to frontend
#
# RESULT: KPI execution now works correctly without AttributeError
# =============================================================================
