# =============================================================================
# Landing KPI Executor - NoneType Fix - ANNOTATED EXTRACT
# =============================================================================
#
# FILE: kg_builder/services/landing_kpi_executor.py
# LINES: 516-526 (NoneType error fix)
#
# CHANGES MADE (November 10, 2025):
# 1. Fixed line 519 to handle None cached_sql when getting length
# 2. Fixed line 525 to handle None cached_sql when calling strip()
#
# WHY: Code was accessing cached_sql without checking if it was None first
#
# ERROR BEFORE FIX:
# {
#   "success": true,
#   "execution_id": 169,
#   "data": {
#     "execution_status": "failed",
#     "error_message": "object of type 'NoneType' has no len()"
#   }
# }
#
# SOLUTION: Added None checks before accessing cached_sql properties
# =============================================================================

# -----------------------------------------------------------------------------
# CONTEXT: What this code does
# -----------------------------------------------------------------------------
# This section of code is checking if KPI has cached SQL that can be reused
# instead of generating new SQL via LLM.
#
# FIELDS FROM DATABASE:
# - isSQLCached (bool): Flag indicating if SQL is cached
# - cached_sql (str or None): The actual cached SQL query
# - isAccept (bool): Flag indicating if cached SQL was accepted/validated
#
# PROBLEM: cached_sql can be None even when isSQLCached is True
# -----------------------------------------------------------------------------

# Lines 516-521: Logging Cache Field Analysis
# WHY: Debugging to see what values we have
logger.info(f"   Cache Field Analysis:")
logger.info(f"      isSQLCached: {is_sql_cached} (type: {type(is_sql_cached)})")
logger.info(f"      cached_sql exists: {bool(cached_sql)}")

# =====================================================================
# LINE 519: CRITICAL FIX #1 - Handle None cached_sql in len()
# =====================================================================
# BEFORE (BROKEN):
#   logger.info(f"      cached_sql length: {len(cached_sql)}")
#   # ERROR: If cached_sql is None, len(None) raises TypeError
#
# AFTER (FIXED):
#   logger.info(f"      cached_sql length: {len(cached_sql) if cached_sql else 0}")
#   # SAFE: Check if cached_sql exists before calling len()
# =====================================================================
logger.info(f"      cached_sql length: {len(cached_sql) if cached_sql else 0}")  # FIXED

# Continue logging
logger.info(f"      cached_sql preview: '{cached_sql[:100]}...' " if cached_sql else "      cached_sql preview: (empty)")
logger.info(f"      isAccept: {is_accept} (type: {type(is_accept)})")

# Lines 523-526: Determine if we should use cached SQL
# WHY: Need to validate that we have valid cached SQL to use

# Check if cache flag is set
is_cached = bool(is_sql_cached)

# =====================================================================
# LINE 525: CRITICAL FIX #2 - Handle None cached_sql in strip()
# =====================================================================
# BEFORE (BROKEN):
#   has_cached_sql = bool(cached_sql.strip())
#   # ERROR: If cached_sql is None, None.strip() raises AttributeError
#
# AFTER (FIXED):
#   has_cached_sql = bool(cached_sql and cached_sql.strip())
#   # SAFE: Check if cached_sql exists AND is not empty/whitespace
#   # HOW IT WORKS:
#   #   - If cached_sql is None: "None and ..." returns False immediately (short-circuit)
#   #   - If cached_sql is "": "'' and ..." returns False (empty string is falsy)
#   #   - If cached_sql is "  ": "'  ' and '  '.strip()" returns False (whitespace only)
#   #   - If cached_sql is "SELECT...": Returns True (valid SQL)
# =====================================================================
has_cached_sql = bool(cached_sql and cached_sql.strip())  # FIXED

# Final decision: Use cache only if both conditions are true
# 1. is_cached = True (isSQLCached flag is set)
# 2. has_cached_sql = True (cached_sql exists and is not empty)
will_use_cache = is_cached and has_cached_sql

logger.info(f"   Cache Decision:")
logger.info(f"      is_cached (flag): {is_cached}")
logger.info(f"      has_cached_sql (content): {has_cached_sql}")
logger.info(f"      will_use_cache (final): {will_use_cache}")


# =============================================================================
# SUMMARY OF CHANGES:
# =============================================================================
#
# PROBLEM:
# Code tried to access properties of cached_sql (len(), strip()) without
# checking if it was None first, causing TypeError/AttributeError.
#
# ROOT CAUSE:
# Database can have isSQLCached=True but cached_sql=NULL, which causes:
# - len(None) -> TypeError: object of type 'NoneType' has no len()
# - None.strip() -> AttributeError: 'NoneType' object has no attribute 'strip'
#
# FIXES:
# 1. Line 519: len(cached_sql) if cached_sql else 0
#    - Returns 0 if cached_sql is None
#    - Safe to log without errors
#
# 2. Line 525: bool(cached_sql and cached_sql.strip())
#    - Short-circuit evaluation: If cached_sql is None, returns False immediately
#    - If cached_sql exists, also checks if it's not just whitespace
#    - Returns True only if we have actual SQL content
#
# RESULT:
# Executor can safely handle cases where cached_sql is None and will
# correctly determine whether to use cached SQL or generate new SQL.
# =============================================================================
