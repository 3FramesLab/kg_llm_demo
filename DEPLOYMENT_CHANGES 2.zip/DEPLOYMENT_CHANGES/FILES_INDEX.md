# Deployment Changes - Files Index

This folder contains annotated versions of all files modified to fix KPI execution and JDBC/ODBC connectivity issues.

## How to Use These Files

Each annotated file contains:
- **Inline comments** explaining every change
- **BEFORE/AFTER comparisons** showing what was changed
- **WHY sections** explaining the reason for each change
- **Summary sections** at the bottom with complete change overview

## Files in This Folder

### 1. README.md
**Purpose**: Complete overview of all changes
**Contains**:
- Summary of all issues fixed
- Build history
- Current deployment status
- Testing instructions
- Links to related files

### 2. Dockerfile_ANNOTATED.dockerfile
**Original File**: `/Dockerfile`
**Changes**:
- Added Microsoft ODBC Driver 17 for SQL Server
- Added MSSQL JDBC driver download (mssql-jdbc-12.4.2.jre11.jar)
- Added unixodbc libraries for pyodbc
- Set JAVA_HOME environment variable
- Created /app/jdbc_drivers directory
- Fixed deprecated apt-key usage with modern signed-by method

**Why Important**: Enables JDBC and ODBC connectivity to MS SQL Server database

### 3. requirements_ANNOTATED.txt
**Original File**: `/requirements.txt`
**Changes**:
- Added JPype1 for JDBC support
- Added graphiti-core per user request
- Removed all version pinning (==, >=)
- Commented out pytest-airflow (package not available)

**Why Important**: Python dependencies required for JDBC/ODBC database connectivity

### 4. 01-backend-deployment_ANNOTATED.yaml
**Original File**: `/openshift/01-backend-deployment.yaml`
**Changes**:
- Updated SOURCE_DB_* environment variables to point to MS SQL Server
- Changed from Oracle defaults (localhost:1521/ORCL) to MSSQL (mssql.cognito-ai-dq-dev.svc.cluster.local:1433/KPI_Analytics)
- Added SOURCE_DB_PASSWORD from mssql-secret

**Why Important**: Configures application to connect to correct database for KPI execution

### 5. routes_KPI_EXECUTE_ENDPOINT_ANNOTATED.py
**Original File**: `/kg_builder/routes.py` (lines 37 and 3529-3581)
**Changes**:
- Added import for get_landing_kpi_executor
- Completely rewrote execute_kpi_mssql endpoint
- Changed from service.execute_kpi() to proper executor pattern
- Fixed AttributeError: 'NLQueryExecutor' object has no attribute 'execute_query'

**Why Important**: Core KPI execution endpoint that was broken due to wrong method call

### 6. landing_kpi_executor_NONETYPE_FIX_ANNOTATED.py
**Original File**: `/kg_builder/services/landing_kpi_executor.py` (lines 516-526)
**Changes**:
- Fixed line 519: Added None check before len(cached_sql)
- Fixed line 525: Added None check before cached_sql.strip()
- Handles cases where cached_sql is None

**Why Important**: Prevents NoneType errors when checking cached SQL

## Build History

| Build | Status | Issue | Fix |
|-------|--------|-------|-----|
| 45-46 | Failed | pytest-airflow not found | Commented out package |
| 47-49 | Failed | curl command error | Split RUN commands |
| 50 | Complete, pod crashed | Missing libodbc.so.2 | Added unixodbc back |
| 51-54 | Failed | apt-key deprecated | Changed to signed-by method |
| 55 | ✅ Complete | - | JDBC/ODBC drivers installed |
| 56 | Cancelled | Wrong approach | Reverted to config approach |
| 57 | Complete, endpoint error | execute_query doesn't exist | Rewrote endpoint |
| 58 | Complete, endpoint error | Missing import | Added import |
| 59 | ✅ Complete | NoneType error | Added None checks |

## Current Status

**Build**: kg-builder-backend-59 ✅
**Deployment**: Successfully rolled out ✅
**Pod**: Running and healthy ✅
**Endpoint**: Fully operational ✅

## Testing

To test the changes:

```bash
# 1. Check pod status
oc get pods -n cognito-ai-dq-dev -l app=kg-builder-backend

# 2. Check logs
oc logs -f deployment/kg-builder-backend -n cognito-ai-dq-dev

# 3. Test health endpoint
curl http://localhost:8000/health

# 4. Test KPI execution endpoint
curl -X POST "http://localhost:8000/v1/landing-kpi-mssql/kpis/10/execute" \
  -H "Content-Type: application/json" \
  -d '{
    "schema_name": "dbo",
    "kg_name": "my_kg"
  }'
```

## Deployment Commands

To apply these changes to a new environment:

```bash
# 1. Build new image with updated Dockerfile
oc start-build kg-builder-backend -n cognito-ai-dq-dev --from-dir=.

# 2. Apply updated deployment configuration
oc apply -f openshift/01-backend-deployment.yaml -n cognito-ai-dq-dev

# 3. Verify rollout
oc rollout status deployment/kg-builder-backend -n cognito-ai-dq-dev

# 4. Check pod logs
oc logs -f deployment/kg-builder-backend -n cognito-ai-dq-dev
```

## Key Technical Concepts

### JDBC (Java Database Connectivity)
- Uses jaydebeapi Python package
- Requires JPype1 (Java-Python bridge)
- Requires Java Runtime (default-jre)
- Requires JDBC driver JAR file (mssql-jdbc-12.4.2.jre11.jar)
- Requires JAVA_HOME environment variable

### ODBC (Open Database Connectivity)
- Uses pyodbc Python package
- Requires unixodbc and unixodbc-dev system packages
- Requires Microsoft ODBC Driver 17 for SQL Server
- Requires proper signed-by keyring setup (modern method, not deprecated apt-key)

### Executor Pattern
- **Wrong**: `service.execute_kpi()` -> calls `executor.execute_query()` ❌
- **Correct**: `get_landing_kpi_executor()` -> calls `executor.execute_kpi_async()` ✅

## Contact

If you have questions about these changes, contact the development team.

## Related Documentation

- [OpenShift Deployment Guide](../docs/OPENSHIFT_DEPLOYMENT.md)
- [Code Changes Summary](../CODE_CHANGES_SUMMARY.md)
- [Local Development Guide](../docs/LOCAL_DEVELOPMENT_GUIDE.md)
